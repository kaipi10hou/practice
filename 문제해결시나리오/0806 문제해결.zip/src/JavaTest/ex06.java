package JavaTest;

import java.util.Scanner;

class score {
	String name;
	double kor;
	double eng;
	double mat;
	double sum;

	score() {

	}

	score(String a, double b, double c, double d) {
		name = a;
		kor = b;
		eng = c;
		mat = d;
		sum = b + c + d;
	}
}

public class ex06 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		score[] sar = new score[5];

		for (int i = 0; i < sar.length; i++) {
			String a;
			double b;
			double c;
			double d;
			System.out.println("�л�" + (i + 1) + "" + " �̸�");
			a = sc.next();
			System.out.println("�л�" + (i + 1) + "" + " �����");
			b = sc.nextDouble();
			System.out.println("�л�" + (i + 1) + "" + " �����");
			c = sc.nextDouble();
			System.out.println("�л�" + (i + 1) + "" + " ���м���");
			d = sc.nextDouble();

			score s = new score(a, b, c, d);
			sar[i] = s;
		}

		score temp = null;
		int k=sar.length-1;
		for (int j = 0;j<sar.length-1; j++) {
			 
			for (int i = 0;i < k; i++) {
				if (sar[i].sum > sar[i + 1].sum) {
					temp = sar[i];
					sar[i] = sar[i + 1];
					sar[i + 1] = temp;
				}
			}k--;
		}
		System.out.print("������ ");
		for (int i = sar.length - 1, j = 0; i >= 0; i--) {

			System.out.print((++j) + "�� " + sar[i].name + ", ");
		}

		sc.close();
	}

}