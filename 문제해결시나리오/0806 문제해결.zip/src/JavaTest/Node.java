package JavaTest;


public class Node {
	Card card;
	Node next;

	public Node() {

	}

	public Node(Card card) {
		this.card = card;
	}
}
