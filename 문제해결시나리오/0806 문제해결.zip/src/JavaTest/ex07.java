package JavaTest;

import java.util.Scanner;

public class ex07 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("10���� �Է�: ");
		int a = sc.nextInt();
		int i;
		int[] arr = new int[10];

		for (i = 0;; i++) {
			if (a == 1) {
				arr[i] = a;
				break;
			}
			arr[i] = a % 2;
			a /= 2;
		}
		System.out.print("2���� ��ȯ >> ");
		for(;i>=0;i--)
			System.out.print(arr[i]);

		sc.close();
	}
}