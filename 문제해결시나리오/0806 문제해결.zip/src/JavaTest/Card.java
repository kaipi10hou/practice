package JavaTest;

public class Card {
		String name;
		String dept;
		String tel;
		
		Card(){
			
		}
		Card(String name, String dept, String tel){
			this.name = name;
			this.dept = dept;
			this.tel = tel;
		}
		
	}
