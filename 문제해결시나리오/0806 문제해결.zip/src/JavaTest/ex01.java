package JavaTest;

import java.util.Scanner;

public class ex01 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("������ �Է����ּ���>");
		int num = sc.nextInt();

		System.out.println(fac(num));

		sc.close();

	}

	static int fac(int num) {
		if (num <= 1)
			return 1;
		return num * fac(num - 1);

	}
}