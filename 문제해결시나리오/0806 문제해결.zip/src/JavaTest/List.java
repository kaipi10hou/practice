package JavaTest;

public class List {
	Node head;
	Node tail;

	List() {
		head = null;
		tail = null;
	}

	public void add(Card card) { //���� �տ� �ֱ�

		Node temp = new Node();
		temp.card = card;
		temp.next = head;
		head = temp;
	}

	public void delete(Card card) {
		Node pre = null, temp;
		temp = head;
		while ((temp != null) && (temp.card != card)) {
			pre = temp;
			temp = temp.next;
		}
		if (temp == null) {
			System.out.println("������ �����ϴ�.");
			return;
		}
		pre.next = temp.next;

	}

	public void addtail(Card card) { 
		Node temp = new Node();
		temp.card = card;
		temp.next = null;

		if (head == null) {
			head = temp;
			tail = temp;
			return;
		}
		tail.next = temp;
		tail = temp;

	}
}
