package JavaTest;

public class ex08 {
	public static void main(String[] args) {
		int[][] arr= new int[5][5];
		int a = 0;
		for(int i = 0; i<5; i++) {
			for(int j= 0; j<=i; j++) {
				arr[i][j]=++a;
				System.out.print(a+" ");
			}System.out.println();
		}
		
	}
}
